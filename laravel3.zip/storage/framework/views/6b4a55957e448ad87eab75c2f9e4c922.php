<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('admin.admincss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body id="page-top">
    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('users'); ?>
</body>
<?php echo $__env->make('admin.adminscript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</html>
<?php /**PATH D:\laragon\www\projek\resources\views/admin/adminmaster.blade.php ENDPATH**/ ?>