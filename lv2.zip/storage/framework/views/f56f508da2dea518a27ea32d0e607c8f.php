    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-5">
                <div class="section_tittle">
                    <p>Macam-macam</p>
                    <h2>Paket Catering</h2>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="nav nav-tabs food_menu_nav" id="myTab" role="tablist">
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori => $menuList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="<?php echo e($loop->first ? 'active' : ''); ?>" id="<?php echo e(str_replace(' ', '-', $kategori)); ?>-tab"
                            data-toggle="tab" href="#<?php echo e(str_replace(' ', '-', $kategori)); ?>" role="tab"
                            aria-controls="<?php echo e(str_replace(' ', '-', $kategori)); ?>"
                            aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>"><?php echo e($kategori); ?> <img
                                src="assets/img/icon/play.svg" alt="play"></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="tab-content" id="myTabContent">
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori => $menuList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tab-pane fade show <?php echo e($loop->first ? 'active' : ''); ?>"
                            id="<?php echo e(str_replace(' ', '-', $kategori)); ?>" role="tabpanel"
                            aria-labelledby="<?php echo e(str_replace(' ', '-', $kategori)); ?>-tab">
                            <div class="row">
                                <?php $__currentLoopData = $menuList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-6 col-lg-6">
                                        <div class="single_food_item media">
                                            <img src="<?php echo e(Storage::url($menu->gambar)); ?>" alt="<?php echo e($menu->title); ?>">
                                            <div class="media-body align-self-center">
                                                <h3><?php echo e($menu->title); ?></h3>
                                                <p><?php echo e($menu->deskripsi); ?></p>
                                                <h5>Rp. <?php echo e(number_format($menu->harga, 0, ',', '.')); ?></h5>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php /**PATH D:\laragon\www\projek\resources\views/menu.blade.php ENDPATH**/ ?>