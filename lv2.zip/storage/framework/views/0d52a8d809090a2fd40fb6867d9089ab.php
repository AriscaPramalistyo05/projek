<footer class="footer-area">
    <div class="container">
        <div class="row">
            <div class="col-xl-3 col-sm-6 col-md-3 col-lg-3">
                <div class="single-footer-widget footer_1">
                    <h4>About Us</h4>
                    <p>Dioli lahir dari usaha
                        kecil di rumah dengan cita rasa yang autentik.
                    </p>
                </div>
            </div>

            <div class="col-xl-3 col-sm-6 col-md-3 col-lg-3">
                <div class="single-footer-widget footer_2">
                    <h4>Contact us</h4>
                    <div class="contact_info">
                        <p><span> Alamat :</span> Jl. Roro Mendut No 10 Pati </p>
                        <p><span> Whatsapp :</span> +62 8050 1204 9030 </p>
                        <p><span> Email : </span>diolicatering1@gmail.com </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright_part_text">
            <div class="row">
                <div class="col-lg-8">
                    <p class="footer-text m-0">
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        Copyright &copy;
                        <script>
                            document.write(new Date().getFullYear());
                        </script> Catering Dioli build <i class="ti-heart" aria-hidden="true"></i> by <a
                            href="https://github.com/AriscaPramalistyo05" target="_blank">L'ars Dev | RPL-2022</a>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </p>
                </div>
                <div class="col-lg-4">
                    <div class="copyright_social_icon text-right">
                        <a href="https://web.facebook.com/?ariska.pramalistyo.9%3Fmibextid=ZbWKwL&_rdc=1&_rdr"><i
                                class="fab fa-facebook-f"></i></a>
                        <a href="https://www.instagram.com/tyo_ariezca?igshid=ZDdkNTZiNTM%3D"><i
                                class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\laragon\www\projek\resources\views/include/footer.blade.php ENDPATH**/ ?>