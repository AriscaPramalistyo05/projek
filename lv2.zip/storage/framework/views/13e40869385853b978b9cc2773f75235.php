

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col">
                <h1>Edit Entry</h1>
            </div>
        </div>

        <form action="<?php echo e(route('admin.blog.update', ['id' => $blog->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="edit-category">Category</label>
                <select class="form-control" id="edit-category" name="category" required>
                    <option value="blog" <?php if($blog->category === 'blog'): ?> selected <?php endif; ?>>Blog</option>
                    <option value="feedback" <?php if($blog->category === 'feedback'): ?> selected <?php endif; ?>>Feedback</option>
                </select>
            </div>

            <div id="blog-fields" <?php if($blog->category === 'feedback'): ?> style="display: none;" <?php endif; ?>>
                <div class="form-group">
                    <label for="gambar">Gambar</label>
                    <input type="file" class="form-control" id="gambar" name="gambar">
                    <?php if($blog->foto): ?>
                        <img src="<?php echo e(asset('storage/' . $blog->foto)); ?>" alt="<?php echo e($blog->title); ?>" style="width: 100px;">
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="edit-title">Title</label>
                    <input type="text" class="form-control" id="edit-title" name="title"
                        value="<?php echo e($blog->title); ?>">
                </div>
                <div class="form-group">
                    <label for="edit-content">Content</label>
                    <textarea class="form-control" id="edit-content" name="content" rows="5"><?php echo e($blog->content); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="edit-date">Date</label>
                    <input type="text" class="form-control" id="edit-date" name="date"
                        value="<?php echo e($blog->date); ?>">
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\projek\resources\views/admin/blog/edit.blade.php ENDPATH**/ ?>