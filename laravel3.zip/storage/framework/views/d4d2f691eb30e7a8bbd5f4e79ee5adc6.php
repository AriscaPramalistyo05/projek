

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Edit Menu</h1>
        <form action="<?php echo e(route('admin.menu.update', $menu->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="title">Title</label>
                <input type="text" class="form-control" id="title" name="title" value="<?php echo e($menu->title); ?>" required>
            </div>
            <div class="form-group">
                <label for="deskripsi">Deskripsi</label>
                <textarea class="form-control" id="deskripsi" name="deskripsi" required><?php echo e($menu->deskripsi); ?></textarea>
            </div>
            <div class="form-group">
                <label for="harga">Harga</label>
                <input type="number" class="form-control" id="harga" name="harga" value="<?php echo e($menu->harga); ?>"
                    required>
            </div>
            <div class="form-group">
                <label for="kategori">Kategori</label>
                <select class="form-control" id="kategori" name="kategori" required>
                    <option value="Murah" <?php echo e($menu->kategori == 'Murah' ? 'selected' : ''); ?>>Murah
                    </option>
                    <option value="Ekonomi" <?php echo e($menu->kategori == 'Ekonomi' ? 'selected' : ''); ?>>Ekonomi
                    </option>
                    <option value="Premium" <?php echo e($menu->kategori == 'Premium' ? 'selected' : ''); ?>>Premium
                    </option>
                    <option value="Snack" <?php echo e($menu->kategori == 'Snack' ? 'selected' : ''); ?>>Snack</option>
                    <option value="Minuman" <?php echo e($menu->kategori == 'Minuman' ? 'selected' : ''); ?>>Minuman</option>
                </select>
            </div>
            <div class="form-group">
                <label for="gambar">Gambar</label>
                <input type="file" class="form-control" id="gambar" name="gambar">
                <img src="<?php echo e(asset('storage/' . $menu->gambar)); ?>" alt="<?php echo e($menu->title); ?>" style="width: 100px;">
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="<?php echo e(route('admin.menu.index')); ?>" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\projek\resources\views/admin/menu/edit.blade.php ENDPATH**/ ?>