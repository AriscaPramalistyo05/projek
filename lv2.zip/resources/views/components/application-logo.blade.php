<img src="{{ asset('assets/img/logologin.png') }}" alt="Logo" style="height: 90px; width: auto;">
