

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1>Edit Koki</h1>
        <form action="<?php echo e(route('admin.koki.update', ['id' => $koki->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="name">Nama</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo e($koki->nama); ?>" required>
            </div>
            <div class="form-group">
                <label for="position">Jabatan</label>
                <input type="text" class="form-control" id="position" name="position" value="<?php echo e($koki->jabatan); ?>"
                    required>
            </div>
            <div class="form-group">
                <label for="photo">Foto</label>
                <input type="file" class="form-control-file" id="photo" name="photo">
            </div>
            <div class="form-group">
                <label for="instagram">Instagram</label>
                <input type="text" class="form-control" id="instagram" name="instagram" value="<?php echo e($koki->instagram); ?>">
            </div>
            <div class="form-group">
                <label for="facebook">Facebook</label>
                <input type="text" class="form-control" id="facebook" name="facebook" value="<?php echo e($koki->facebook); ?>">
            </div>
            <div class="form-group">
                <label for="x">X (Pengganti Twitter)</label>
                <input type="text" class="form-control" id="x" name="x" value="<?php echo e($koki->x); ?>">
            </div>
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            <a href="<?php echo e(route('admin.koki.index')); ?>" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\projek\resources\views/admin/koki/edit.blade.php ENDPATH**/ ?>