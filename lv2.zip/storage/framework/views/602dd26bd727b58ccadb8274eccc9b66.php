<!doctype html>
<html lang="en">

<head>
    <?php echo $__env->make('include.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <!--::header part start::-->
    <header class="main_menu home_menu">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <a class="navbar-brand" href="#"> <img src="assets/img/logo3.png" alt="logo"> </a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse main-menu-item justify-content-end"
                            id="navbarSupportedContent">
                            <ul class="navbar-nav me-auto"> <!-- Add me-auto for margin-right auto -->
                                <li class="nav-item">
                                    <a class="nav-link" href="#home">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#about">About</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#menu">Menu</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#program">Program</a>
                                </li>
                                
                                <li class="nav-item">
                                    <a class="nav-link" href="#kontak">Contact</a>
                                </li>
                            </ul>
                            <div class="menu_btn d-flex align-items-center d-none d-lg-block ml-3">
                                <!-- Add ml-3 for margin-left -->
                                <?php if(Route::has('login')): ?>
                                    <?php if(auth()->guard()->check()): ?>
                                        <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'class' => 'btn_1 me-2','onclick' => 'event.preventDefault();
                                            this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'class' => 'btn_1 me-2','onclick' => 'event.preventDefault();
                                            this.closest(\'form\').submit();']); ?>
                                                <?php echo e(__('Log Out')); ?>

                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
                                        </form>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('login')); ?>" class="btn_1 me-2">Login</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <!-- Header part end-->

    <!-- banner part start-->
    <section class="banner_part" id="home">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="banner_text">
                        <div class="banner_text_iner">
                            <h5>Authentic Taste, Heartfelt Experience</h5>
                            <h1>From Our Kitchen to Your Heart</h1>
                            <p>Dari Dapur Kecil Kami sampai ke Meja Anda: Kenikmatan Kuliner Indonesia yang Menggugah
                                Selera dan Menyentuh Hati</p>
                            <div class="banner_btn">
                                <div class="banner_btn_iner">
                                    <a href="#reservasi" class="btn_2">Pesan <img src="assets/img/icon/left_1.svg"
                                            alt=""></a>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- banner part start-->

    <!--::exclusive_item_part start::-->
    
    <!--::exclusive_item_part end::-->

    <!-- about part start-->
    <section class="about_part" id="about">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-sm-4 col-lg-5 offset-lg-1">
                    <div class="about_img">
                        <img src="assets/img/about.png" alt="">
                    </div>
                </div>
                <div class="col-sm-8 col-lg-4">
                    <div class="about_text">
                        <h5>Our History</h5>
                        <h2>Tentang Dioli</h2>
                        <p>Dioli lahir dari semangat dan kecintaan kami terhadap masakan Indonesia, tumbuh dari usaha
                            kecil di rumah dengan cita rasa yang autentik. Kami percaya bahwa lezatnya makanan tidak
                            harus berkompromi dengan keaslian rasa dan kualitas. Dari dapur kecil kami, kami ingin
                            berbagi kenikmatan kuliner Indonesia dengan dunia, menjadikan setiap hidangan Dioli sebagai
                            sebuah pengalaman yang menggugah selera dan menyentuh hati. </p>
                        <br>
                        <ul>
                            <li><i class="bi bi-check-circle"></i> Program "Sejuta Rasa, Satu Cerita.</li>
                            <li><i class="bi bi-check-circle"></i> Kemitraan dengan Petani Lokal.</li>
                            <li><i class="bi bi-check-circle"></i> Paket Hadiah Khusus.</li>
                        </ul>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- about part end-->

    <!-- intro_video_bg start-->
    
    <!-- intro_video_bg part start-->

    <!-- food_menu start-->
    <section class="food_menu gray_bg" id="menu">
        <?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>

    <!-- food_menu part end-->

    <!--::chefs_part start::-->
    
    <!--::chefs_part end::-->

    <!--::regervation_part start::-->
    <section class="regervation_part section_padding" id="kontak">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12">
                    <section id="reservasi">
                        <div class="section_tittle">
                            <p>Pesan</p>
                            <h2>Untuk acara</h2>
                        </div>
                    </section>
                    <div class="regervation_part_iner">
                        <form id="pesanForm" action="<?php echo e(route('pesan.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <?php if(auth()->check()): ?>
                                        <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                                        <input type="text" class="form-control form-white" placeholder="Name *"
                                            value="<?php echo e(auth()->user()->name); ?>" readonly>
                                    <?php else: ?>
                                        <input type="hidden" name="user_id" value="">
                                        <input type="text" class="form-control form-white" placeholder="Name *"
                                            value="" readonly>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-6">
                                    <?php if(auth()->check()): ?>
                                        <input type="email" class="form-control form-white"
                                            placeholder="Email address *" value="<?php echo e(auth()->user()->email); ?>"
                                            readonly>
                                    <?php else: ?>
                                        <input type="email" class="form-control form-white"
                                            placeholder="Email address *" value="" readonly>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-6">
                                    <input type="number" class="form-control form-white" name="phone"
                                        placeholder="Phone number *" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <input id="datepicker" type="text" class="form-control form-white"
                                        name="date" placeholder="Date *" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="timeInput" class="form-white">Time *</label>
                                    <div class="position-relative">
                                        <input type="time" class="form-control form-white" name="time"
                                            id="timeInput" placeholder="Your Time *" required>
                                        <i class="ti-time" role="right-icon"></i>
                                    </div>
                                </div>
                                <div class="form-group col-md-12">
                                    <textarea class="form-control form-white" name="note" id="Textarea" rows="4" placeholder="Your Note *"
                                        required></textarea>
                                </div>
                            </div>
                            <div class="regerv_btn">
                                <button type="submit" class="btn_4">Order</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 mb-4 mt-3">
                    
                    <div class="embed-responsive embed-responsive-4by3">
                        <iframe class="embed-responsive-item"
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3962.107110939624!2d111.04687970985682!3d-6.756791166041565!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e70d34005eb24fb%3A0x515537d5f9034f30!2sShofiya%20celullar!5e0!3m2!1sid!2sid!4v1720674002369!5m2!1sid!2sid"
                            allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>

            </div>
        </div>

    </section>
    <!--::regervation_part end::-->

    <!--::review_part start::-->
    
    <!--::review_part end::-->

    <!--::exclusive_item_part start::-->
    <section class="blog_item_section blog_section section_padding" id="program">
        <div class="container">
            <div class="row">
                <div class="col-xl-5">
                    <div class="section_tittle">
                        <p>Berita Terbaru</p>
                        <h2>Kegiatan/Program Kami</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php
                    use App\Models\Blog;
                    $blogs = Blog::all();
                ?>
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 col-lg-4">
                        <div class="single_blog_item">
                            <div class="single_blog_img">
                                <img src="img/blog/blog_1.png" alt="">
                            </div>
                            <div class="single_blog_text">
                                <div class="date">
                                    <a href="#" class="date_item"><?php echo e($blog->date->format('M d, Y')); ?></a>
                                    <a href="#" class="date_item"> <span>#</span> <?php echo e($blog->title); ?></a>
                                </div>
                                <h3><a href=""><?php echo e($blog->content); ?></a></h3>
                                <a href="#" class="btn_3">Read More <img src="img/icon/left_1.svg"
                                        alt=""></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
    </section>
    <!--::exclusive_item_part end::-->

    <!-- footer part start-->
    <?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- footer part end-->

    
    <?php echo $__env->make('include.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>

</html>
<?php /**PATH D:\laragon\www\projek\resources\views/homepage.blade.php ENDPATH**/ ?>