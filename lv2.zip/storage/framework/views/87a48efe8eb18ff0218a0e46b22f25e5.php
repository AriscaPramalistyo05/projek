

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1>Users</h1>
        <div class="d-flex justify-content-end mb-3">
        </div>
        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>User Type</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->usertype == 1 ? 'Admin' : 'User'); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.user.edit', ['id' => $user->id])); ?>"
                                class="btn btn-sm btn-warning">Edit</a>
                            <?php if($user->usertype == '0'): ?>
                                <a href="<?php echo e(route('admin.user.delete', ['id' => $user->id])); ?>"
                                    onclick="return confirm('Apakah Anda yakin ingin menghapus pengguna ini?')"
                                    class="btn btn-sm btn-danger">Hapus</a>
                            <?php else: ?>
                                Tidak Bisa Hapus
                            <?php endif; ?>

                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\projek\resources\views/admin/user/index.blade.php ENDPATH**/ ?>